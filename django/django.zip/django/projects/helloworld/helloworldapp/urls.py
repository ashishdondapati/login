from helloworld.urls import path
from . import views 
urlpatterns=[path('',views.home,name='home'),
path('add',views.add,name='add')


]# we used home fnc here so create the func in views file in app